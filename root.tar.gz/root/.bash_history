 poweroff
 poweroff
cat > /etc/apt/sources.list <<'EOF'
deb http://deb.debian.org/debian bullseye main
deb http://security.debian.org/debian-security bullseye-security main
deb http://deb.debian.org/debian bullseye-updates main
EOF

apt clean
rm -rf /var/lib/apt/lists
rm -rf /var/lib/apt/lists/*
apt update
ip r
ping -c2 192.168.0.1
printf "nameserver 1.1.1.1\nnameserver 8.8.8.8\n" > /etc/resolv.conf
chattr +i /etc/resolv.conf
sed -i 's|http://|https://|g' /etc/apt/sources.list
apt clean
rm -rf /var/lib/apt/lists/*
apt update
printf "nameserver 1.1.1.1\nnameserver 8.8.8.8\n" >/etc/resolv.conf
printf "nameserver 1.1.1.1\nnameserver 8.8.8.8\n" > /etc/resolv.conf
vi /etc/network/interfaces
systemct1 restart networking || reboot
ping -c2 1.1.1.1
ping -c2 deb.debian.org
ping -c2 192.168.0.1
ping -c2 192.168.0.150
apt update
apt list --upgradeable
apt update
apt update -y
apt upgrade -y
apt install nano -y
systemctl enable ssh
reboot
systemctl enable ssh
apt update
apt install -y openssh-server
dpkg -l | grep openssh
systemctl daemon-reload
systemctl enable --now ssh
systemctl status ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
reboot
exit
exit
nano /www_dir/index.php
nano /www_dir/index.php
reboot
lsblk
umount /home
fdisk /dev/sdb
fdisk /dev/sdb
fdisk /dev/sdb
fdisk /dev/sdb
fdisk /dev/sdb
lsblk
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
mkdir /mnt/sdb1
mkdir /mnt/sdb2
mount /dev/sdb1 /mnt/sdb1
mount /dev/sdb2 /mnt/sdb2
df -h
nano /etc/fstab
nano /etc/fstab
nano /etc/fstab
nano /etc/fstab
mount -a
df -h
echo "Particion 1_Prueba" > /mnt/sdb1/test.txt
echo "Particion 2_Prueba" > /mnt/sdb2/test.txt
cat /mnt/sdb1/test.txt
cat /mnt/sdb2/test.txt
reboot
df -h
ls /mnt/sdb1
ls /mnt/sdb2
cat /mnt/sdb1/test.txt
cat /mnt/sdb2/test.txt
reboot
rsync
rsync -a /www_dir/ /mnt/sdb1/
mkdir -p /www_dir /backup_dir
nano /etc/fstab
df -h
umount /mnt/sdb1 2>/dev/null || true
umount /mnt/sdb2 2>/dev/null || true
mount -a
df -h
df -h | egrep 'www_dir|backup_dir|sdb[12]'
rsyn -a /mnt/sdb1/ /www_dir/ 2>/dev/null || true
chown -R www-data:www-data /www_dir
find /www_dir -type d -exec chmod 755 {} \;
find /www_dir -type f -exec chmod 644 {} \;
df -h
system restart apache2
systemctl restart apache2
cat >/usr/local/sbin/backup_full.sh <<'EOF'
#!/bin/bash
EOF

set -euo pipefail
DATE="$(date +%Y%m%d-%H%M%S)"
DEST="/backup_dir/www_backup_${DATE}.tgz"
tar -czf "$DEST" -c /www_dir
tar -czf "$DEST" -c / www_dir
rm -f /backup_dir/www_backup_*.tgz
cat >/usr/local/sbin/backup_full.sh <<'EOF'
#!/bin/bash
set -euo pipefail
DATE="$(date +%Y%m%d-%H%M%S)"
DEST="/backup_dir/www_backup_${DATE}.tgz"
tar -czf "$DEST" -c /www_dir
EOF

cat >/usr/local/sbin/backup_full.sh <<'EOF'
#!/bin/bash
set -euo pipefail
DATE="$(date +%Y%m%d-%H%M%S)"
DEST="/backup_dir/www_backup_${DATE}.tgz"
tar -czf "$DEST" -C /www_dir
ls -1t /backup_dir/www_backup_*.tgz 2>/dev/null | tail -n +8 | xargs -r rm -f

echo "Backup creado y guardado en: $DEST"
EOF

chmod 700 /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
ls -lh /backup_dir
tar -tzf /backup_dir/www_backup_*.tgz | head
rf -f /usr/local/sbin/backup_full.sh
rm -f /usr/local/sbin/backup_full.sh
ls  /usr/local/sbin/backup_full.sh
ls /usr/local/sbin/backup_full.sh
mdir -p /usr/local/sbin
mkdir -p /usr/local/sbin
cat >/usr/local/sbin/backup_full.sh <<'EOF'
EOF

nano /usr/local/sbin/backup_full.sh
chmod 700 /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
ls -lh /backup_dir
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
ls -lh /backup_dir
tar -tzf /backup_dir/www_backup_*.tgz | head
tar -tzf "$(ls -1t /backup_dir/www_backup_*.tgz | head -n1)" | head
nano
nano /usr/local/sbin/backup_full.sh
chmod 700 /usr/local/sbin/backup_web.sh
chmod 700 /usr/local/sbin/backup_www.sh
ls -l /ussr/local/sbin/
ls -l /usr/local/sbin/
chmod 700 /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
ls -lh /backup_dir
tr -tzf "$(ls -1t /backup_dir/backup_*.tgz | head -n1)" | head
tar -tzf "$(ls -1t /backup_dir/backup_*.tgz | head -n1)" | head
tail -n 20 /var/log/backup.log
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
tail -n 20 /var/log/backup.log
crontab -e
crontab -1
crontab -l
systemctl status cron
/usr/local/sbin/backup_full.sh
ls -lh  /backup_dir
tail -20 /var/log/backup.log
nano /usr/local/sbin/backup_full.sh
crontab -e
crontab -e
crontab -e
cmod 700 /usr/local/sbin/backup_full.sh
chmod 700 /usr/local/sbin/backup_full.sh
systemctl status cron
/usr/local/sbin/backup_full.sh
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh
chmod 700 /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh /var.log
/usr/local/sbin/backup_full.sh /var/log
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh /var/log
nano /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh /var/log
/usr/local/sbin/backup_full.sh /www_dir
ls -lh
ls -lh  /backup_dir
ls -lh  /backup_dir | tail -n 5
tail -20 /var/log/backup.log
bash -n /usr/local/sbin/backup_full.sh
head -n 40 /usr/local/sbin/backup_full.sh
crontab -l
systemctl is-active cron
reboot
mkdir /tmp/arreglando_cagadas_temporal
cp -a /www_dir /tmp/arreglando_cagadas_temporal/www_dir_temp
cp -a /backup_dir /tmp/arreglando_cagadas_temporal/backup_dir_temp
fdisk /dev/sdb
ls -lah /tmp/arreglando_cagadas_temporal
mount /dev/sdb /www_dir
df -h
umoun /mnt/sdb1
umount /mnt/sdb1
umount /mnt/sdb2
umount /www_dir
umount /backup_dir
fdisk /dev/sdb
fdisk /dev/sdb
df -h
mount | grep sdb
df -h
fdisk /dev/sdb
umount /backup_dir
df -h
fdisk /dev/sdb
mkfs.ext4 /ddev/sdb2
mkfs.ext4 /dev/sdb2
mount /backup_dir
df -h
lsblk
ls /backup_dir
umount /www_dir
fdisk /dev/sdb
mkfs.ext4 /dev/sdb2
mkfs.ext4 /dev/sdb1
mount /dev/sdb1 /www_dir
cp -rp /arreglando_cagadas_temporal/www_dir_temp/* /www_dir/
cp -rp /arreglando_cagadas_temporal/www_dir_backup/* /www_dir/
df -h
lsbllk
lsblk
ls /arreglando_cagadas_temporal
find / -type d -name "*cagadas*" 2>/dev/null
/usr/local/sbin/backup_full.sh /www_dir
head -n 40 /usr/local/sbin/backup_full.sh
/usr/local/sbin/backup_full.sh /var/log
tail -20 /var/log/backup.log
ls /tmp
ls /tmp/arrelgando_cagadas_temporal
